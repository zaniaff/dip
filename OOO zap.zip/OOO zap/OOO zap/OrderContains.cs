﻿using OOO_zap.DataBaze;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOO_zap
{
    public static class OrderContains
    {
        public static ObservableCollection<Products> ListProduct;

        static OrderContains()
        {
            ListProduct = new ObservableCollection<Products>();
        }
    }
}
