﻿using OOO_zap.DataBaze;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace OOO_zap.Windows
{
    /// <summary>
    /// Логика взаимодействия для Basket.xaml
    /// </summary>
    public partial class Basket : Window
    {
        user21Entities Context;
       
        public Basket(user21Entities DataBaseContext)
        {
            InitializeComponent();
            Context = DataBaseContext;
            
            ComboPoint.ItemsSource = Context.Points.ToList();
            GridMain.ItemsSource = OrderContains.ListProduct;
            TxBoxSum.Text = SumOrder();
            TxBoxDiscount.Text = SumDiscount();
        }

        public string SumOrder()
        {
            decimal SumOrder = 0;
            foreach (var itme in OrderContains.ListProduct)
            {
                var SumDiscount = (itme.Price * itme.Discount) / 100;
                SumOrder = Convert.ToDecimal(SumOrder + (itme.Price - SumDiscount) * itme.ProductSum);

            }
            return SumOrder.ToString();
        }

        public string SumDiscount()
        {
            decimal DiscountOrder = 0;
            foreach (var itme in OrderContains.ListProduct)
            {
                var SumDiscount = (itme.Price * itme.Discount) / 100;
                DiscountOrder = Convert.ToDecimal(DiscountOrder + SumDiscount * itme.ProductSum);

            }
            return DiscountOrder.ToString();
        }
           
    }
}
