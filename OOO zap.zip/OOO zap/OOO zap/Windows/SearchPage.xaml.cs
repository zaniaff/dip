﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OOO_zap.DataBaze;

namespace OOO_zap.Windows
{
    /// <summary>
    /// Логика взаимодействия для SearchPage.xaml
    /// </summary>
    public partial class SearchPage : Page
    {
        user21Entities Context;
        
        public SearchPage()
        {
            InitializeComponent();
            Context = new user21Entities();
            GridMain.ItemsSource = Context.Products.ToList();
            
            if(OrderContains.ListProduct.Count == 0)
            {
                BtnOrder.Visibility = Visibility.Collapsed;
            }

        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            Basket basket = new Basket(Context);
            basket.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Products CurrentProduct = GridMain.SelectedItem as Products;
            if (CurrentProduct == null)
                MessageBox.Show("выберите продукт", "уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            else
            {
                Products FindProduct = OrderContains.ListProduct.FirstOrDefault(p => p.id == CurrentProduct.id);
                if(FindProduct == null)
                {
                    CurrentProduct.ProductSum = 1;
                    OrderContains.ListProduct.Add(CurrentProduct);
                }
                else
                {
                    foreach(var item in OrderContains.ListProduct)
                    {
                        if(item.id == CurrentProduct.id)
                            item.ProductSum++;
                        

                    }
                }  
                
                BtnOrder.Visibility = Visibility.Visible;
            }

          
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Products> products = Context.Products.ToList();

            products = products.Where(p => p.NameProduct.ToLower().Contains(SearchBox.Text.ToLower())).ToList();
            GridMain.ItemsSource = products;
            if(SearchBox.Text == "")
            {
                MessageBox.Show("ничего не найдено");
                return;
                
            }
        }
    }
}
